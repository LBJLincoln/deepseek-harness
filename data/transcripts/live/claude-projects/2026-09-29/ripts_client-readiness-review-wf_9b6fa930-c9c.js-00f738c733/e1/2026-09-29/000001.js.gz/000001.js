export const meta = {
  name: 'client-readiness-review',
  description: 'Three lens reviews of every client-facing Daliesk deliverable, then one verified fix pass pushed by 14:30Z',
  phases: [
    { title: 'Review', detail: 'CIO, CISO and presentation lenses over the live deck, briefing, summary and reports' },
    { title: 'Fix', detail: 'one agent verifies every blocker/major finding against the source and fixes the real ones' },
  ],
}

const SCRATCH = '/tmp/claude-0/-home-user-deepseek-harness/f53f80cc-1f77-5d02-a862-99d59ffabdce/scratchpad'
const RULES = `
Context: Daliesk is this repository's pilot enterprise of AI agents (a scheduler runs a cycle at :13 past every even UTC hour: intake, shift of model departments, blind review, assembly, recertification, push, plus function seats, roster, publish, record). The operator presents it to Fortune-500 clients at 17:03Z today (${args.now} now). The operator said "none of what I can show to the client is worthy of a fortune500 company" and wants the live view "actionable, big picture and epic".
Repository: /home/user/deepseek-harness, development branch claude/coding-agent-harness-u9l4gt (never edit the main checkout).
Client-facing surfaces:
- The command deck on GitHub Pages: https://lbjlincoln.github.io/deepseek-harness/ with routes /, /ops (live operations), /briefing (the client briefing, printable), /process, /safety, /workflow. Source: apps/command-deck. The /ops data comes from a public read-only Supabase relay the deck reads.
- docs/client/daliesk-executive-summary.md (+ .zh.md), docs/client/data-handling.md (+ .zh.md), the root README.md (+ README.zh.md), data/code-safety/reports/2026-09-27-nodegoat-12-base-d/SECURITY-ASSESSMENT.md and .html.
- The ground truth for every figure: pnpm run enterprise:report -- --since 2026-09-28T17:03:33Z (run it in the main checkout; it reads the ledger, records, git and GitHub's Branch CI answers), pnpm run enterprise:verdicts, data/enterprise/ledger.jsonl, data/enterprise/cycles/, data/enterprise/shifts/.
Viewing pages: use Playwright from the repository (import from '/home/user/deepseek-harness/node_modules/.pnpm/playwright@1.61.1/node_modules/playwright/index.mjs') and launch Chromium with executablePath '/opt/pw-browsers/chromium'; never install browsers. Plain curl GETs of the public Pages URLs and the public relay are fine. Do not use WebFetch or Firecrawl.
Never print or write credentials (never read /root/.dsh-mirror-token into output), never write any e-mail address except [REDACTED-EMAIL], never kill processes you did not start, write scratch files only under ${SCRATCH}/<your lens>/.`

const FINDINGS = {
  type: 'object',
  properties: {
    findings: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          surface: { type: 'string', description: 'URL or repository path' },
          location: { type: 'string', description: 'selector, section heading, or file:line' },
          problem: { type: 'string' },
          evidence: { type: 'string', description: 'what you saw or ran that proves it: quoted text, figure vs its source, screenshot path' },
          severity: { type: 'string', enum: ['blocker', 'major', 'minor'] },
          fix: { type: 'string', description: 'the concrete change, naming the source file to edit when known' },
        },
        required: ['surface', 'location', 'problem', 'evidence', 'severity', 'fix'],
      },
    },
    summary: { type: 'string', description: 'two or three sentences: would you put this in front of the client today, and why' },
  },
  required: ['findings', 'summary'],
}

const LENSES = [
  {
    key: 'cio',
    prompt: `You are a Fortune-500 CIO deciding whether to pilot Daliesk, reviewing its deliverables adversarially an hour before the pitch. Read-only: change nothing.
Check: (1) every figure on /, /ops, /briefing, the executive summary and the README against the ground truth commands (flag any number that differs, is stale, or is stated without its window or basis); (2) contradictions between surfaces (e.g. shipped counts, who started what, CI verdicts, seat counts); (3) claims a CIO would discount: vague value statements, unexplained jargon, anything that overclaims autonomy (the truth: tickets shipped with supervisor steps; T-0020/T-0021 came from a scheduler cycle whose push the supervisor completed; CI verdicts are green only for T-0020/T-0021); (4) whether the briefing answers: what is it, what did it do in 24 hours, what does it cost, what are the risks, what do we need to decide; (5) broken links. Screenshot what you cite.`,
  },
  {
    key: 'ciso',
    prompt: `You are a Fortune-500 CISO reviewing Daliesk's client deliverables for security and data-handling claims before a pitch. Read-only: change nothing.
Check: (1) docs/client/data-handling.md and the executive summary: every claim about where client code and transcripts go, retention, masking, and who can read what, against the actual code (data/transcripts/tools/, scripts/transcripts-capture.sh, apps/command-deck/mirror, the relay) and the public repository; (2) containment claims about the unattended agents against examples/headless-agent/tests/fixtures/enterprise-shift/README.md's statement of what is not confined, scripts/enterprise-acceptance.ts and the driver; flag any surface that claims more than the code enforces; (3) the security assessment report: overclaims, unverified findings presented as confirmed; (4) exposure on public surfaces: fetch the public relay's /ops payload and the published Pages build and look for secrets, e-mail addresses, internal hostnames, tokens, private paths; (5) what a CISO must be told before any client repository touches this system. Screenshot or quote what you cite.`,
  },
  {
    key: 'presentation',
    prompt: `You are the presentation lead who must put the Daliesk command deck on a boardroom screen and a phone in an hour. Read-only: change nothing.
Using Playwright, open https://lbjlincoln.github.io/deepseek-harness/ routes /, /ops, /briefing (and glance at /process, /safety, /workflow) at 1600x900 and 390x844, in dark and light color schemes, waiting for data to load. For each: console errors, failed requests, blank or perpetually-loading panels, text clipped or overlapping, unreadable contrast, horizontal scroll on phone, charts whose labels collide, placeholder or debug text, stale "live" badges, WebGL fallback behavior (also try with WebGL disabled via --disable-webgl). For /ops judge it against the operator's ask: actionable (what needs me now, with the next action), big picture (whole enterprise at a glance), epic (felt scale and motion) — name what concretely falls short. For /briefing, render it to PDF with page.pdf (A4) and check page breaks and tables. Save screenshots under your scratch dir and cite their paths.`,
  },
]

phase('Review')
const reviews = await parallel(LENSES.map(lens => () =>
  agent(`${lens.prompt}\n${RULES}\nReturn every finding with evidence; severity blocker = would embarrass the operator in front of the client or states something false; major = a client would notice and discount it; minor = polish.`,
    { label: `review:${lens.key}`, phase: 'Review', schema: FINDINGS })
    .then(r => r ? { lens: lens.key, ...r } : null)))
const done = reviews.filter(Boolean)
const all = done.flatMap(r => r.findings.map(f => ({ lens: r.lens, ...f })))
const serious = all.filter(f => f.severity !== 'minor')
const minor = all.filter(f => f.severity === 'minor')
log(`${done.length}/3 reviews returned: ${all.length} findings, ${serious.length} blocker/major, ${minor.length} minor (minor ones go to the fixer as optional)`)

phase('Fix')
const fixReport = await agent(`You are the one engineer who fixes the client-readiness findings below before the 17:03Z pitch. Finish and push by ${args.fixDeadline}; start nothing new after ${args.stopBy}.
${RULES}
Working rules:
- Create your own worktree: git -C /home/user/deepseek-harness fetch origin claude/coding-agent-harness-u9l4gt && git -C /home/user/deepseek-harness worktree add /home/user/deepseek-harness/.claude/worktrees/final-fixes -b agent/final-fixes origin/claude/coding-agent-harness-u9l4gt, then pnpm install --offline --frozen-lockfile inside it.
- Heavy commands (typecheck, --coverage, doc-sync, build, e2e, the deck's next build) run as flock /tmp/dsh-heavy.lock <command>; focused tests only; the Bash tool's default timeout is 2 min, pass explicit timeouts.
- Commit as git -c user.name=Claude -c user.email=[REDACTED-EMAIL] commit, message ending with exactly:
Co-Authored-By: Claude Opus 5.5 <[REDACTED-EMAIL]>
Claude-Session: https://claude.ai/code/session_01HEXjzxR7CyMizem5kFAB4C
- Push: flock -w 900 /tmp/dsh-push.lock bash -c 'git fetch origin claude/coding-agent-harness-u9l4gt && git rebase origin/claude/coding-agent-harness-u9l4gt && git push origin HEAD:claude/coding-agent-harness-u9l4gt' (a ledger conflict keeps both sides' lines). Never force-push, never open a PR, no model names in committed files beyond the trailer.
- Before every push: pnpm run knip, pnpm run duplication (0 clones), node_modules/.bin/tsx scripts/run-oxlint.ts --deny-warnings <changed files>, typecheck, the specs of what you touched, pnpm run verify-translation-pairing (edit English/Chinese pairs together and re-record with pnpm run verify-translation-pairing --write <the .md>), and the translation-prompt snapshot if you touched a gold pair (root README pair): pnpm exec vitest run --config vitest.snapshot.config.ts scripts/translation-prompt.snapshot.ts (update with -u only for an intended doc change). If you touch the engine (examples/headless-agent/tests/fixtures/enterprise-shift/), also run flock /tmp/dsh-heavy.lock pnpm exec vitest run --config vitest.e2e.config.ts examples/headless-agent/tests/enterprise-shift.e2e.ts. Figures in client documents come from generators (scripts/enterprise-briefing.ts, scripts/enterprise-publish.ts, scripts/enterprise-report.ts): fix the generator and regenerate, never hand-edit a generated figure.
- The deck deploys to Pages from the branch; after your last deck change, confirm the Pages deploy succeeded and re-check the page you fixed.
Process: for each finding, first try to REFUTE it against the source and the live page (reviewers can be wrong). Fix the real blockers first, then majors, then minors if time allows. Group related fixes into a few commits.
Findings (JSON):
${JSON.stringify(serious, null, 1)}
Optional minor findings:
${JSON.stringify(minor, null, 1)}
Reviewers' summaries: ${JSON.stringify(done.map(r => ({ lens: r.lens, summary: r.summary })))}
Return: per finding, its outcome (fixed with SHA / refuted with reason / not done with reason), the SHAs pushed, the checks you ran with results, and what the operator should still know before the pitch.`,
  { label: 'fix:client-readiness', phase: 'Fix' })
return { reviews: done.map(r => ({ lens: r.lens, summary: r.summary, counts: { blocker: r.findings.filter(f => f.severity === 'blocker').length, major: r.findings.filter(f => f.severity === 'major').length, minor: r.findings.filter(f => f.severity === 'minor').length } })), findings: all, fixReport }
