export const meta = {
  name: 'client-grade-audit',
  description: 'Fortune-500 lens audit of every client-facing Daliesk surface, with adversarial verification of serious findings',
  phases: [
    { title: 'Audit', detail: 'five executive lenses read the client-facing surfaces' },
    { title: 'Verify', detail: 'each blocker or major finding is independently re-checked against the files' },
    { title: 'Synthesize', detail: 'one prioritized must-fix list' },
  ],
}

const FINDINGS = {
  type: 'object',
  properties: {
    findings: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          severity: { type: 'string', enum: ['blocker', 'major', 'minor'] },
          surface: { type: 'string', description: 'repo path, route, or URL the client sees' },
          problem: { type: 'string' },
          evidence: { type: 'string', description: 'exact file:line quotes or data that prove the problem' },
          fix: { type: 'string', description: 'concrete change that resolves it' },
        },
        required: ['id', 'severity', 'surface', 'problem', 'evidence', 'fix'],
      },
    },
  },
  required: ['findings'],
}

const VERDICT = {
  type: 'object',
  properties: {
    real: { type: 'boolean' },
    severity: { type: 'string', enum: ['blocker', 'major', 'minor', 'not-a-problem'] },
    reason: { type: 'string' },
  },
  required: ['real', 'severity', 'reason'],
}

const CONTEXT = `Context: DeepSeek Harness repository at /home/user/deepseek-harness (branch claude/coding-agent-harness-u9l4gt), which houses "Daliesk", an AI enterprise (147 seats in 10 divisions; tickets implemented by seat departments, blind-reviewed, CI-verified and shipped by unattended cycles every two hours; ledger at data/enterprise/ledger.jsonl; public command deck apps/command-deck deployed as a static export to https://lbjlincoln.github.io/deepseek-harness/). The operator must present Daliesk to a Fortune 500 client within a day and judges that nothing they can show is worthy of such a client yet. Other agents are right now building a live /ops Operations Center, a /briefing executive page, a 24-hour evidence report, owner requests, and durable transcript capture; do not audit those unbuilt things, audit what exists on the branch now, and name gaps they must close. READ ONLY: do not edit, commit, build heavy targets, or start servers. Do not use web tools (WebFetch, WebSearch, Firecrawl). Quote exact lines as evidence. Prefer fewer, sharper findings over many trivial ones; every finding needs a concrete fix.`

const LENSES = [
  { key: 'cio', prompt: `You are the CIO of a Fortune 500 company evaluating Daliesk as an autonomous software-delivery organization. Judge architecture credibility, operational maturity (unattended operation, recovery from failure such as the container resets documented in git history of 2026-09-28, observability), and whether the claims in README.md, data/enterprise/README.md, apps/command-deck/README.md, docs/architecture.md and the deck's views would survive your technical due diligence.` },
  { key: 'ciso', prompt: `You are the CISO of a Fortune 500 company. Judge security, governance and auditability of Daliesk: sandboxing and the read barrier, secret handling and redaction (data/transcripts tools, enterprise shift redaction), what agents may push and how review gates it, audit trail completeness (ledger, records, transcripts, including the transcript losses of 2026-09-28), data-use terms, supply chain (vendor/, dependencies), and the public exposure of the deck and repository. Find what a security review would block.` },
  { key: 'cfo', prompt: `You are the CFO / procurement lead of a Fortune 500 company. Judge whether Daliesk demonstrates value with evidence: throughput and cost per shipped unit (ledger tokens and seconds), quality (CI verdicts, review rejections), benchmark results (data/proving-ground, dashboard, results notes) and security-review recall (data/code-safety), and whether any figure a client would see is unsupported, stale, cherry-picked or missing its uncertainty.` },
  { key: 'design', prompt: `You are the design director who signs off client-facing material at a Fortune 500 company. Judge the visual and narrative quality of everything a client would see: the command deck's views (read apps/command-deck/app, components, deck/palette.ts, and look at the committed screenshots under apps/command-deck/docs/ and data/proving-ground/dashboard.png with the Read tool), the root README's first screen, data/proving-ground/dashboard.html, and the code-safety reports under data/code-safety. Find what looks amateur, confusing, cluttered, inaccessible, broken on phones, or off-brand, and what a flagship client demo needs that is missing.` },
  { key: 'evidence', prompt: `You are an evidence auditor. List every quantitative or factual claim a client would read in README.md, data/enterprise/README.md, apps/command-deck/README.md, apps/command-deck/public/fixtures/*.json (the deck's data), data/proving-ground/README.md, data/code-safety/README.md and docs/code-safety-poc.md, and check each against the data it depends on (ledger, roster, records, git history). Report claims that are false, stale (for example counts that the current roster or ledger contradicts), unverifiable, or overstated.` },
]

phase('Audit')
const results = await pipeline(
  LENSES,
  lens => agent(`${CONTEXT}\n\n${lens.prompt}\n\nReturn your findings; ids must start with "${lens.key}-".`, { label: `audit:${lens.key}`, phase: 'Audit', schema: FINDINGS }),
  (audit, lens) => {
    if (!audit) return []
    const serious = audit.findings.filter(f => f.severity !== 'minor')
    const minor = audit.findings.filter(f => f.severity === 'minor')
    return parallel(serious.map(f => () =>
      agent(`${CONTEXT}\n\nA reviewer with the ${lens.key} lens reported this finding. Try to REFUTE it by reading the cited files and data yourself: is the problem real as stated, and is the severity right? Default to real=false if the evidence does not hold up.\n\nFinding ${f.id} [${f.severity}] on ${f.surface}\nProblem: ${f.problem}\nEvidence: ${f.evidence}\nProposed fix: ${f.fix}`, { label: `verify:${f.id}`, phase: 'Verify', schema: VERDICT })
        .then(v => ({ ...f, lens: lens.key, verdict: v }))
    )).then(verified => [...verified.filter(Boolean), ...minor.map(f => ({ ...f, lens: lens.key, verdict: null }))])
  },
)

const all = results.filter(Boolean).flat()
const kept = all.filter(f => f.verdict === null || (f.verdict.real && f.verdict.severity !== 'not-a-problem'))
const dropped = all.length - kept.length
log(`${all.length} findings, ${dropped} refuted by verification, ${kept.length} kept`)

phase('Synthesize')
const synthesis = await agent(`${CONTEXT}\n\nHere are the verified findings of a five-lens Fortune 500 audit (JSON). Merge duplicates, order by what most damages a Fortune 500 client presentation first, and group them into work packages an implementing agent can take whole (each package: title, files it touches, the findings it resolves, acceptance criteria). Note which packages overlap with the agents already building /ops, /briefing, the 24-hour report, owner requests and transcript capture, so they can be routed there instead.\n\n${JSON.stringify(kept)}`, { label: 'synthesize', phase: 'Synthesize' })

return { counts: { total: all.length, kept: kept.length, refuted: dropped }, findings: kept, plan: synthesis }
